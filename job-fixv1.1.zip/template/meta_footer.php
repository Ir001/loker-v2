<script data-cfasync="false" src="<?php base_url(); ?>/assets/js/email-decode.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/owlcarousel/owl.carousel.min.js"></script>
<script src="assets/js/jquery-ui.min.js"></script>
<script src="assets/paging/jquery.simplePagination.js"></script>
<script src="assets/js/custom.js"></script>
<script>
$(".search-icone").click(function(){
     // $(".menu").animate({height: "100vh"});
 });
$("#search-box_search_form_3").submit(function(){
	console.log(1);
});
</script>
