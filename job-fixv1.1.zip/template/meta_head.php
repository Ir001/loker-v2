<script src="<?php base_url(); ?>/assets/js/4n2NXumNjtg5LPp6VXLlDicTUfA.js"></script>
<link rel="apple-touch-icon" href="assets/images/favicon.png">
<link rel="shortcut icon" type="image/ico" href="assets/images/favicon.png" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link href="assets/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/matrialize.css" rel="stylesheet">
<link href="assets/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/paging/page.css">
<link rel="stylesheet" href="assets/css/style.css">