<footer id="footer" class="background-color-white">
	<div class="container">
	<div class="vertical-space-100"></div>
				<div class="row">
					<div class="col-lg-4 col-md-6 vertical-space-200">
						<h5>About Us</h5>
						<p class="paregraf" style="margin-bottom: 50px"><a href="<?base_url();?>">Lowongan Kerja ID</a> adalah portal lowongan kerja terbaik yang bisa anda temukan di indonesia. Kami akan memberikan pelayanan informasi lowongan kerja terbaik untuk anda, dan ikut serta dalam mengurangi pengangguran di Indonesia.</p>
						<div class="my-4">
							<a href="#"><i class="fa fa-facebook social-icon"></i></a>
							<a href="#"><i class="fa fa-twitter social-icon"></i></a>
							<a href="#"><i class="fa fa-pinterest-p social-icon"></i></a>
							<a href="#"><i class="fa fa-map-marker social-icon"></i></a>
						</div>
					</div>
									<div class="col-lg-2 col-md-6 vertical-space-2">
										<h5>Company</h5>
										<div class="text">
											<a href="#">About</a>
											<a href="#">Support</a>
											<a href="#">Tems</a>
											<a href="#">Privacy</a>
										</div>
									</div>
									<div class="col-lg-2 col-md-6 vertical-space-2">
										<h5>Supports</h5>
										<div class="text">
											<a href="#">About</a>
											<a href="#">Support</a>
											<a href="#">Tems</a>
											<a href="#">Privacy</a>
										</div>
									</div>
									<div class="col-lg-4 col-md-6 vertical-space-2">
										<h5>Subscribe Us</h5>
										<p>Get latest update and newsletter</p>
										<div class="vertical-space-30"></div>
										<form>
											<input type="email" class="email " placeholder="Email Address " required="">
											<span class="fa fa-envelope email-icone "></span>
					<input type="submit" class="Subscribe" value="Subscribe">
				</form>
			</div>
		</div>
	<div class="vertical-space-60"></div>
	</div>
</footer>